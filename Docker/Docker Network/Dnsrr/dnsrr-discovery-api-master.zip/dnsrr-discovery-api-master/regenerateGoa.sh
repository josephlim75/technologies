mv ./vendor/ ./prevendor/
goagen bootstrap -d github.com/mtenrero/dockerDnsrr-discovery/design
mv ./prevendor/ ./vendor/