#Apache Kafka examples
This repository includes examples demonstrating how to use the New Java Kafka Producer and Consumer.
All examples are based on Kafka 0.11.0.0 and Java 1.7+. 

Some of the example ideas are borrowed from [@confluentinc](https://github.com/confluentinc/examples/), [@gwenshap](https://github.com/gwenshap/kafka-examples) and Apache Kafka Opensource community.
