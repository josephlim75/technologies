package au.com.dius.redshift;

import org.apache.hadoop.mapred.RecordWriter;
import org.apache.hadoop.mapred.Reporter;

import java.io.IOException;

public class ArtistDimensionRecordWriter implements RecordWriter {

  @Override
  public void write(Object o, Object o2) throws IOException {
    //To change body of implemented methods use File | Settings | File Templates.
  }

  @Override
  public void close(Reporter reporter) throws IOException {
    //To change body of implemented methods use File | Settings | File Templates.
  }
}
