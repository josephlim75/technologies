#!/bin/bash

cd /home/hadoop/lib
sudo curl -O http://s3.amazonaws.com/aws-examples.dius.com.au/lib/hue-plugins-2.5.0-cdh4.4.0.jar
sudo curl -O http://s3.amazonaws.com/aws-examples.dius.com.au/lib/postgresql-9.2-1003.jdbc4.jar
sudo curl -O http://s3.amazonaws.com/aws-examples.dius.com.au/lib/sqoop-1.4.4.jar
