Copyright
=========

.. literalinclude:: ../COPYRIGHT

