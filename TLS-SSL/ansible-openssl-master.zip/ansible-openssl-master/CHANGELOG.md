<a name="1.10.0"></a>
## 1.10.0 (2017-12-21)


#### Features

*   replace include with import_tasks for 2.4 ([a21b0b42](https://github.com/weareinteractive/ansible-openssl/commit/a21b0b425199124f2de69c985a361bf2d04de8da))



<a name="1.9.0"></a>
## 1.9.0 (2017-08-18)


#### Features

*   generate csrs ([0abb9d46](https://github.com/weareinteractive/ansible-openssl/commit/0abb9d46d7e7b31ce52b3749125523e1443be956))
*   optionally install cacert roots ([507a6b1e](https://github.com/weareinteractive/ansible-openssl/commit/507a6b1ee0f85ef91c51e912d826ba0c3c10df05))



<a name="1.8.0"></a>
## 1.8.0 (2016-04-18)


#### Bug Fixes

*   fix deprication warnings in ansible 2.0 ([404b0987](https://github.com/weareinteractive/ansible-openssl/commit/404b09879a5cbe2e2fa6bed92f23d234c879673e))

#### Features

*   add default key & cert group & owner variables ([2fd69ddd](https://github.com/weareinteractive/ansible-openssl/commit/2fd69ddd98d4060c0ccd11d4c74dd07103b54187))
*   user ansible-role docgen to generate README ([26693335](https://github.com/weareinteractive/ansible-openssl/commit/2669333508bf90c86d1dfe1f1f137685c478503a))
*   add CHANGELOG ([bd041fbf](https://github.com/weareinteractive/ansible-openssl/commit/bd041fbfd3b99b719cefd35e0879eec7e427f36b))
*   make mode, owner and group overrideable ([046dcc40](https://github.com/weareinteractive/ansible-openssl/commit/046dcc4096d01df37dc8726e3980d48d2a6cffaf))



