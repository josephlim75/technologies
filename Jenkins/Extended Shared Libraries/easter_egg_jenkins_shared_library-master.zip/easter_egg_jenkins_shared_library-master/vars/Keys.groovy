
class Keys {
    static def MY_GLOBAL_VAR3 = "beethoven"
}

