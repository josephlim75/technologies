#!/usr/bin/env bash
set -ex

sbt clean test
