#!/usr/bin/env bash
set -ex

sbt docker:publishLocal